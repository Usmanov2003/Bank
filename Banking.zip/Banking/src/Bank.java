//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

import java.io.Serializable;
import javax.swing.DefaultListModel;

public class Bank implements Serializable {
    private static final long serialVersionUID = 1L;
    BankAccount[] accounts = new BankAccount[100];
    public String filepath = "C:\\Temp\\Bank.txt";

    public Bank() {
    }

    public int addAccount(BankAccount acc) {

        int i;
        for(i = 0; i < 100 && this.accounts[i] != null; ++i) {
        }

        this.accounts[i] = acc;
        return i;
    }

    public int addAccount(String name, double balance, double maxWithLimit) {
        SavingsAccount acc = new SavingsAccount(name, balance, maxWithLimit);
        return this.addAccount(acc);
    }

    public int addAccount(String name, double balance, String tradeLicense) {
        CurrentAccount acc = new CurrentAccount(name, balance, tradeLicense);
        return this.addAccount(acc);
    }

    public int addAccount(String name, String institutionName, double balance, double min_balance) {
        StudentAccount acc = new StudentAccount(name, balance, institutionName);
        return this.addAccount(acc);
    }

    public BankAccount findAccount(String aacountNum) {
        for(int i = 0; i < 100 && this.accounts[i] != null; ++i) {
            if (this.accounts[i].acc_num.equals(aacountNum)) {
                return this.accounts[i];
            }
        }

        return null;
    }

    public void deposit(String aacountNum, double amt) throws InvalidAmount, AccNotFound {
        if (amt < 0.0) {
            throw new InvalidAmount("Invalid Deposit amount");
        } else {
            BankAccount temp = this.findAccount(aacountNum);
            if (temp == null) {
                throw new AccNotFound("Account Not Found");
            } else {
                if (temp != null) {
                    temp.deposit(amt);
                }

            }
        }
    }

    public void withdraw(String aacountNum, double amt) throws MaxBalance, AccNotFound, MaxWithdraw, InvalidAmount {
        BankAccount temp = this.findAccount(aacountNum);
        if (temp == null) {
            throw new AccNotFound("Account Not Found");
        } else if (amt <= 0.0) {
            throw new InvalidAmount("Invalid Amount");
        } else if (amt > temp.getbalance()) {
            throw new MaxBalance("Insufficient Balance");
        } else {
            if (temp != null) {
                temp.withdraw(amt);
            }

        }
    }

    public DefaultListModel<String> display() {
        DefaultListModel<String> list = new DefaultListModel();

        for(int i = 0; i < 100 && this.accounts[i] != null; ++i) {
            list.addElement(this.accounts[i].toString());
        }

        return list;
    }
}
