//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Menu extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    public Menu() {
        this.setTitle("Banking System");
        this.setDefaultCloseOperation(3);
        this.setBounds(100, 100, 450, 300);
        this.contentPane = new JPanel();
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout((LayoutManager)null);
        JLabel lblBankingSystem = new JLabel("Banking System");
        lblBankingSystem.setHorizontalAlignment(0);
        lblBankingSystem.setFont(new Font("Tahoma", 1, 24));
        lblBankingSystem.setBounds(10, 11, 414, 59);
        this.contentPane.add(lblBankingSystem);
        JButton btnAddAccount = new JButton("Add Account");
        btnAddAccount.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GUIForm.addaccount.setVisible(true);
            }
        });
        btnAddAccount.setBounds(122, 81, 177, 23);
        this.contentPane.add(btnAddAccount);
        JButton btnDepositToAccount = new JButton("Deposit To Account");
        btnDepositToAccount.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GUIForm.depositacc.setVisible(true);
            }
        });
        btnDepositToAccount.setBounds(122, 115, 177, 23);
        this.contentPane.add(btnDepositToAccount);
        JButton btnWithdrawFromAccount = new JButton("Withdraw From Account");
        btnWithdrawFromAccount.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GUIForm.withdraw.setVisible(true);
            }
        });
        btnWithdrawFromAccount.setBounds(122, 149, 177, 23);
        this.contentPane.add(btnWithdrawFromAccount);
        JButton btnDisplayAccountList = new JButton("Display Account List");
        btnDisplayAccountList.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GUIForm.UpdateDisplay();
                GUIForm.displaylist.setVisible(true);
            }
        });
        btnDisplayAccountList.setBounds(122, 183, 177, 23);
        this.contentPane.add(btnDisplayAccountList);
        JButton btnExit = new JButton("Exit");
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                System.exit(0);
            }
        });
        btnExit.setBounds(122, 217, 177, 23);
        this.contentPane.add(btnExit);
    }
}
