

import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class WithdrawAcc extends JFrame implements Serializable {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;

    public WithdrawAcc() {
        this.setTitle("Withdraw From Account");
        this.setDefaultCloseOperation(2);
        this.setBounds(100, 100, 450, 300);
        this.contentPane = new JPanel();
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout((LayoutManager)null);
        JLabel lblDepositToAccount = new JLabel("Withdraw From Account");
        lblDepositToAccount.setFont(new Font("Tahoma", 1, 16));
        lblDepositToAccount.setHorizontalAlignment(0);
        lblDepositToAccount.setBounds(10, 11, 414, 36);
        this.contentPane.add(lblDepositToAccount);
        JLabel lblName = new JLabel("Account Number:");
        lblName.setHorizontalAlignment(4);
        lblName.setBounds(0, 86, 106, 14);
        this.contentPane.add(lblName);
        this.textField = new JTextField();
        this.textField.setBounds(116, 83, 216, 20);
        this.contentPane.add(this.textField);
        this.textField.setColumns(10);
        this.textField_1 = new JTextField();
        this.textField_1.setColumns(10);
        this.textField_1.setBounds(116, 147, 216, 20);
        this.contentPane.add(this.textField_1);
        JLabel lblAmount = new JLabel("Amount:");
        lblAmount.setHorizontalAlignment(4);
        lblAmount.setBounds(10, 150, 96, 14);
        this.contentPane.add(lblAmount);
        JButton btnDeposit = new JButton("Withdraw");
        btnDeposit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                FileIO file = new FileIO();
                Bank bank = file.Read();
                String aacountNum = WithdrawAcc.this.textField.getText();
                double amt = Double.parseDouble(WithdrawAcc.this.textField_1.getText());

                try {
                    JOptionPane.showConfirmDialog(WithdrawAcc.this.getComponent(0), "Confirm?");
                    bank.withdraw(aacountNum, amt);
                    JOptionPane.showMessageDialog(WithdrawAcc.this.getComponent(0), "Success");
                    WithdrawAcc.this.dispose();
                } catch (MaxBalance var8) {
                    JOptionPane.showMessageDialog(WithdrawAcc.this.getComponent(0), "Insufficient Balance");
                    JOptionPane.showMessageDialog(WithdrawAcc.this.getComponent(0), "Failed");
                    WithdrawAcc.this.textField.setText((String)null);
                    WithdrawAcc.this.textField_1.setText((String)null);
                } catch (AccNotFound var9) {
                    JOptionPane.showMessageDialog(WithdrawAcc.this.getComponent(0), "Sorry! Account Not Found");
                    JOptionPane.showMessageDialog(WithdrawAcc.this.getComponent(0), "Failed");
                    WithdrawAcc.this.textField.setText((String)null);
                    WithdrawAcc.this.textField_1.setText((String)null);
                } catch (MaxWithdraw var10) {
                    JOptionPane.showMessageDialog(WithdrawAcc.this.getComponent(0), "Maximum Withdraw Limit Exceed");
                    JOptionPane.showMessageDialog(WithdrawAcc.this.getComponent(0), "Failed");
                    WithdrawAcc.this.textField.setText((String)null);
                    WithdrawAcc.this.textField_1.setText((String)null);
                } catch (InvalidAmount var11) {
                    JOptionPane.showMessageDialog(WithdrawAcc.this.getComponent(0), "Invalid Amount");
                    JOptionPane.showMessageDialog(WithdrawAcc.this.getComponent(0), "Failed");
                    WithdrawAcc.this.textField.setText((String)null);
                    WithdrawAcc.this.textField_1.setText((String)null);
                }

                file.Write(bank);
                GUIForm.UpdateDisplay();
                WithdrawAcc.this.textField.setText((String)null);
                WithdrawAcc.this.textField_1.setText((String)null);
            }
        });
        btnDeposit.setBounds(73, 212, 89, 23);
        this.contentPane.add(btnDeposit);
        JButton btnReset = new JButton("Reset");
        btnReset.setBounds(243, 212, 89, 23);
        this.contentPane.add(btnReset);
        btnReset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                WithdrawAcc.this.textField.setText((String)null);
                WithdrawAcc.this.textField_1.setText((String)null);
            }
        });
    }
}
