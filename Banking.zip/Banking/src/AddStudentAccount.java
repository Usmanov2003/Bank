//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class AddStudentAccount extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;

    public AddStudentAccount() {
        this.setTitle("Add Student Account");
        this.setDefaultCloseOperation(2);
        this.setBounds(100, 100, 450, 300);
        this.contentPane = new JPanel();
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout((LayoutManager)null);
        JLabel lblAddCurrentAccount = new JLabel("Add Student Account ");
        lblAddCurrentAccount.setFont(new Font("Tahoma", 1, 16));
        lblAddCurrentAccount.setHorizontalAlignment(0);
        lblAddCurrentAccount.setBounds(10, 11, 414, 34);
        this.contentPane.add(lblAddCurrentAccount);
        JLabel lblName = new JLabel("Name:");
        lblName.setFont(new Font("Tahoma", 0, 11));
        lblName.setBounds(10, 72, 124, 14);
        this.contentPane.add(lblName);
        this.textField = new JTextField();
        this.textField.setBounds(144, 69, 254, 20);
        this.contentPane.add(this.textField);
        this.textField.setColumns(10);
        JLabel lblBalance = new JLabel("Balance:");
        lblBalance.setFont(new Font("Tahoma", 0, 11));
        lblBalance.setBounds(10, 118, 124, 14);
        this.contentPane.add(lblBalance);
        this.textField_1 = new JTextField();
        this.textField_1.setColumns(10);
        this.textField_1.setBounds(144, 115, 254, 20);
        this.contentPane.add(this.textField_1);
        JLabel lblMaximumWithdrawLimit = new JLabel("Institution Name:");
        lblMaximumWithdrawLimit.setFont(new Font("Tahoma", 0, 11));
        lblMaximumWithdrawLimit.setBounds(10, 163, 135, 14);
        this.contentPane.add(lblMaximumWithdrawLimit);
        this.textField_2 = new JTextField();
        this.textField_2.setColumns(10);
        this.textField_2.setBounds(144, 160, 254, 20);
        this.contentPane.add(this.textField_2);
        JButton btnAdd = new JButton("Add");
        btnAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                FileIO file = new FileIO();
                Bank bank = file.Read();
                String name = AddStudentAccount.this.textField.getText();
                double bal = Double.parseDouble(AddStudentAccount.this.textField_1.getText());
                String insname = AddStudentAccount.this.textField_2.getText();
                if (name != null && !(bal <= 0.0) && insname != null) {
                    bank.addAccount(name, bal, insname);
                    JOptionPane.showConfirmDialog(AddStudentAccount.this.getComponent(0), "Confirm?");
                    file.Write(bank);
                    GUIForm.UpdateDisplay();
                    JOptionPane.showMessageDialog(AddStudentAccount.this.getComponent(0), "Success");
                    AddStudentAccount.this.textField.setText((String)null);
                    AddStudentAccount.this.textField_1.setText((String)null);
                    AddStudentAccount.this.textField_2.setText((String)null);
                    AddStudentAccount.this.dispose();
                } else {
                    JOptionPane.showMessageDialog(AddStudentAccount.this.getComponent(0), "Typing Mismatch!! Try Again");
                    AddStudentAccount.this.textField.setText((String)null);
                    AddStudentAccount.this.textField_1.setText((String)null);
                    AddStudentAccount.this.textField_2.setText((String)null);
                }

            }
        });
        btnAdd.setBounds(86, 209, 89, 23);
        this.contentPane.add(btnAdd);
        JButton btnReset = new JButton("Reset");
        btnReset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                AddStudentAccount.this.textField.setText((String)null);
                AddStudentAccount.this.textField_1.setText((String)null);
                AddStudentAccount.this.textField_2.setText((String)null);
            }
        });
        btnReset.setBounds(309, 209, 89, 23);
        this.contentPane.add(btnReset);
    }
}
