public class MaxBalance extends Exception {
    private static final long serialVersionUID = 1L;

    MaxBalance(String s) { super(s);}
}
