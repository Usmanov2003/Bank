//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package GUI;

import Data.FileIO;
import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class AddCurrentAccount extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;

    public AddCurrentAccount() {
        this.setTitle("Add Current Account");
        this.setDefaultCloseOperation(2);
        this.setBounds(100, 100, 450, 300);
        this.contentPane = new JPanel();
        this.contentPane.setBackground(SystemColor.activeCaption);
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout((LayoutManager)null);
        JLabel var1 = new JLabel("Add Current Account ");
        var1.setFont(new Font("Tahoma", 1, 16));
        var1.setHorizontalAlignment(0);
        var1.setBounds(10, 11, 414, 34);
        this.contentPane.add(var1);
        JLabel var2 = new JLabel("Name:");
        var2.setFont(new Font("Tahoma", 0, 11));
        var2.setBounds(10, 72, 124, 14);
        this.contentPane.add(var2);
        this.textField = new JTextField();
        this.textField.setBounds(144, 69, 254, 20);
        this.contentPane.add(this.textField);
        this.textField.setColumns(10);
        JLabel var3 = new JLabel("Balance:");
        var3.setFont(new Font("Tahoma", 0, 11));
        var3.setBounds(10, 118, 124, 14);
        this.contentPane.add(var3);
        this.textField_1 = new JTextField();
        this.textField_1.setColumns(10);
        this.textField_1.setBounds(144, 115, 254, 20);
        this.contentPane.add(this.textField_1);
        JLabel var4 = new JLabel("Trade Licence Number:");
        var4.setFont(new Font("Tahoma", 0, 11));
        var4.setBounds(10, 163, 135, 14);
        this.contentPane.add(var4);
        this.textField_2 = new JTextField();
        this.textField_2.setColumns(10);
        this.textField_2.setBounds(144, 160, 254, 20);
        this.contentPane.add(this.textField_2);
        JButton var5 = new JButton("Add");
        var5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent var1) {
                String var2 = AddCurrentAccount.this.textField.getText();
                double var3 = Double.parseDouble(AddCurrentAccount.this.textField_1.getText());
                String var5 = AddCurrentAccount.this.textField_2.getText();
                if (var3 < 5000.0) {
                    JOptionPane.showMessageDialog(AddCurrentAccount.this.getComponent(0), "Minimum Limit 5000", "Warning", 0);
                    AddCurrentAccount.this.textField.setText((String)null);
                    AddCurrentAccount.this.textField_1.setText((String)null);
                    AddCurrentAccount.this.textField_2.setText((String)null);
                } else if (var2 != null && !(var3 <= 0.0) && var5 != null) {
                    int var6 = JOptionPane.showConfirmDialog(AddCurrentAccount.this.getComponent(0), "Confirm?");
                    if (var6 == 0) {
                        int var7 = 0;

                        try {
                            var7 = FileIO.bank.addAccount(var2, var3, var5);
                        } catch (Exception var9) {
                            var9.printStackTrace();
                        }

                        DisplayList.arr.addElement(FileIO.bank.getAccounts()[var7].toString());
                        JOptionPane.showMessageDialog(AddCurrentAccount.this.getComponent(0), "Success");
                        AddCurrentAccount.this.dispose();
                    } else {
                        JOptionPane.showMessageDialog(AddCurrentAccount.this.getComponent(0), "Failed");
                        AddCurrentAccount.this.textField.setText((String)null);
                        AddCurrentAccount.this.textField_1.setText((String)null);
                        AddCurrentAccount.this.textField_2.setText((String)null);
                    }
                } else {
                    JOptionPane.showMessageDialog(AddCurrentAccount.this.getComponent(0), "Typing Mismatch!! Try Again");
                    AddCurrentAccount.this.textField.setText((String)null);
                    AddCurrentAccount.this.textField_1.setText((String)null);
                    AddCurrentAccount.this.textField_2.setText((String)null);
                }

            }
        });
        var5.setBounds(86, 209, 89, 23);
        this.contentPane.add(var5);
        JButton var6 = new JButton("Reset");
        var6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent var1) {
                AddCurrentAccount.this.textField.setText((String)null);
                AddCurrentAccount.this.textField_1.setText((String)null);
                AddCurrentAccount.this.textField_2.setText((String)null);
            }
        });
        var6.setBounds(309, 209, 89, 23);
        this.contentPane.add(var6);
    }
}
