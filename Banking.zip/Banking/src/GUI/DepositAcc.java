package GUI;

import Data.FileIO;
import Exceptions.AccNotFound;
import Exceptions.InvalidAmount;
import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class DepositAcc extends JFrame implements Serializable {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;

    public DepositAcc() {
        this.setTitle("Deposit to Account");
        this.setDefaultCloseOperation(2);
        this.setBounds(100,100,450,300);
        this.contentPane = new JPanel();
        this.contentPane.setBackground(SystemColor.activeCaption);
        this.contentPane.setBorder(new EmptyBorder(5,5,5,5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout((LayoutManager)null);
        JLabel var1 = new JLabel("Deposit to Account");
        var1.setFont(new Font("Tahoma",1, 16));
        var1.setHorizontalAlignment(0);
        var1.setBounds(10,11,414,36);
        this.contentPane.add(var1);
        JLabel var2 = new JLabel("Account Number: ");
        var2.setHorizontalAlignment(4);
        var2.setBounds(0,86,111,14);
        this.contentPane.add(var2);
        this.textField = new JTextField();
        this.textField.setBounds(121,83,211,20);
        this.contentPane.add(this.textField);
        this.textField.setColumns(10);
        this.textField_1 = new JTextField();
        this.textField_1.setColumns(10);
        this.textField_1.setBounds(121,147,211,20);
        this.contentPane.add(this.textField_1);
        JLabel var3 = new JLabel("Amount");
        var3.setHorizontalAlignment(4);
        var3.setBounds(0,150,111,14);
        this.contentPane.add(var3);
        JButton var4 = new JButton("Deposit");
        var4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent var1) {
                String var2 = DepositAcc.this.textField.getText();
                double var3 = Double.parseDouble(DepositAcc.this.textField_1.getText());
                int var5 = JOptionPane.showConfirmDialog(DepositAcc.this.getComponent(0),"Confirm?");
                if (var5 == 0) {
                    try {
                        FileIO.bank.deposit(var2, var3);
                        JOptionPane.showMessageDialog(DepositAcc.this.getComponent(0),"Deposit Successful");
                        DepositAcc.this.dispose();
                        DepositAcc.this.textField.setText((String)null);
                        DepositAcc.this.textField_1.setText((String)null);
                    } catch (InvalidAmount var11) {
                        JOptionPane.showMessageDialog(DepositAcc.this.getComponent(0),"Sorry! Deposit Amount is Onvalid");
                    } catch (AccNotFound var12) {
                        JOptionPane.showMessageDialog(DepositAcc.this.getComponent(0),"Sorry! Account is not Found");
                    } finally {
                        DepositAcc.this.textField.setText((String)null);
                        DepositAcc.this.textField_1.setText((String)null);
                    }
                } else {
                    DepositAcc.this.textField.setText((String)null);
                    DepositAcc.this.textField_1.setText((String)null);
                }
            }
        });
        var4.setBounds(73,212,89,23);
        this.contentPane.add(var4);
        JButton var5 = new JButton("Reset");
        var5.setBounds(243,212,89,23);
        this.contentPane.add(var5);
        var5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent var1) {
                DepositAcc.this.textField.setText((String)null);
                DepositAcc.this.textField.setText((String)null);
            }
        });
    }
}
