package GUI;

import Data.FileIO;
import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.SystemColor;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

public class DisplayList extends JFrame {
    private static final long serialVersionUID = 1L;
    static DefaultListModel<String> arr = new DefaultListModel();
    private JPanel contentPane;

    public DisplayList() {
        this.setTitle("Account List");
        this.setDefaultCloseOperation(2);
        this.setBounds(100,100,649,474);
        this.contentPane = new JPanel();
        this.contentPane.setBackground(SystemColor.activeCaption);
        this.contentPane.setBorder(new EmptyBorder(5,5,5,5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout((LayoutManager)null);
        JLabel var1 = new JLabel("Account List");
        var1.setFont(new Font("Tahoma",1,18));
        var1.setHorizontalAlignment(0);
        var1.setBounds(0,11,623,31);
        this.contentPane.add(var1);
        JScrollPane var2 = new JScrollPane();
        var2.setVerticalScrollBarPolicy(22);
        var2.setHorizontalScrollBarPolicy(32);
        var2.setBounds(10,66,613,358);
        this.contentPane.add(var2);
        arr = FileIO.bank.display();
        JList var3 = new JList(arr);
        var2.setViewportView(var3);
    }

}
