//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package GUI;

import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Login {
    public JFrame frame;
    private JTextField textField;
    private JPasswordField textField_1;

    public Login() {
        this.initialize();
    }

    private void initialize() {
        this.frame = new JFrame();
        this.frame.setBounds(100, 100, 450, 300);
        this.frame.setDefaultCloseOperation(3);
        this.frame.setTitle("Banking System");
        this.frame.getContentPane().setLayout((LayoutManager)null);
        JLabel var1 = new JLabel("Banking System");
        var1.setFont(new Font("Tahoma", 1, 17));
        var1.setBounds(147, 11, 151, 41);
        this.frame.getContentPane().add(var1);
        JLabel var2 = new JLabel("Login Screen");
        var2.setFont(new Font("Tahoma", 0, 13));
        var2.setBounds(170, 63, 101, 23);
        this.frame.getContentPane().add(var2);
        JLabel var3 = new JLabel("Username:");
        var3.setFont(new Font("Tahoma", 0, 12));
        var3.setBounds(55, 119, 64, 23);
        this.frame.getContentPane().add(var3);
        JLabel var4 = new JLabel("Password:");
        var4.setFont(new Font("Tahoma", 0, 12));
        var4.setBounds(55, 159, 64, 23);
        this.frame.getContentPane().add(var4);
        this.textField = new JTextField();
        this.textField.setBounds(130, 121, 86, 20);
        this.frame.getContentPane().add(this.textField);
        this.textField.setColumns(10);
        this.textField.setText("admin");
        this.textField_1 = new JPasswordField();
        this.textField_1.setBounds(130, 161, 86, 20);
        this.frame.getContentPane().add(this.textField_1);
        this.textField_1.setColumns(10);
        JButton var5 = new JButton("Login");
        var5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent var1) {
                Login.this.textField.setText("admin");
                String var2 = "admin";
                String var3 = Login.this.textField_1.getText();
                if (var2.equals("admin") && var3.equals("admin")) {
                    JOptionPane.showMessageDialog(Login.this.frame.getComponent(0), "Login Successfully");
                    Login.this.frame.setVisible(false);
                    GUIForm.menu.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(Login.this.frame.getComponent(0), "Login Failed");
                }

            }
        });
        var5.setBounds(260, 138, 89, 23);
        this.frame.getContentPane().add(var5);
    }
}
