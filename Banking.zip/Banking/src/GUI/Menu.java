package GUI;

import Data.FileIO;
import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Menu extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    public Menu() {
        this.setTitle("Banking System");
        this.setBounds(100,100,649,474);
        this.contentPane = new JPanel();
        this.contentPane.setBackground(SystemColor.activeCaption);
        this.contentPane.setForeground(SystemColor.activeCaption);
        this.contentPane.setBorder(new EmptyBorder(5,5,5,5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout((LayoutManager)null);
        JLabel var1 = new JLabel("Banking System");
        var1.setHorizontalAlignment(0);
        var1.setFont(new Font("Tahoma",1,24));
        var1.setBounds(0,69,613,59);
        this.contentPane.add(var1);
        FileIO.Read();
        JButton var2 = new JButton("Deposit To Account");
        var2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent var1) {
                if (!GUIForm.depositacc.isVisible()) {
                    GUIForm.depositacc.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(Menu.this.getComponent(0),"Already Opened", "Warning",0);
                }
            }
        });
        var2.setBounds(217,213,194,33);
        this.contentPane.add(var2);
        JButton var3 = new JButton("Withdraw From Account");
        var3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent var1) {
                if(!GUIForm.withdraw.isVisible()) {
                    GUIForm.withdraw.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(Menu.this.getComponent(0),"Already Opened", "Warning",0);
                }
            }
        });
        var3.setBounds(217,256,194,33);
        this.contentPane.add(var3);
        JButton var4 = new JButton("Display Account List");
        var4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent var1) {
                if(!GUIForm.displaylist.isVisible()) {
                    GUIForm.displaylist.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(Menu.this.getComponent(0),"Already Opened", "Warning",0);
                }
            }
        });
        var4.setBounds(217,300,194,32);
        this.contentPane.add(var4);
        JButton var5 = new JButton("Exit");
        var5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent var1) {
                JOptionPane.showMessageDialog(Menu.this.getComponent(0),"Thanks For Using");
                FileIO.Write();
                System.exit(0);
            }
        });
        var5.setBounds(217,343,194,33);
        this.contentPane.add(var5);
        JButton var6 = new JButton("Add Account");
        var6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }

            public void actionperformed(ActionEvent var1) {
                if (!GUIForm.addaccount.isVisible()) {
                    GUIForm.addaccount.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(Menu.this.getComponent(0),"Already Opened", "Warning",0);
                }
            }
        });
        var6.setBounds(217,166,194,36);
        this.contentPane.add(var6);
        JLabel var7 = new JLabel("New label");
        var7.setIcon(new ImageIcon(Menu.class.getResource("/img/1.png")));
        var7.setBounds(347,16,216,213);
        this.contentPane.add(var7);
        new ImageIcon("1.png");
    }
}
