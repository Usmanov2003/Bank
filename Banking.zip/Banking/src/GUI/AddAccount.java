//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package GUI;

import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class AddAccount extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    public AddAccount() {
        this.setTitle("Add Account");
        this.setDefaultCloseOperation(2);
        this.setBounds(100, 100, 450, 300);
        this.contentPane = new JPanel();
        this.contentPane.setBackground(SystemColor.activeCaption);
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout((LayoutManager)null);
        JButton var1 = new JButton("Add Saving Account");
        var1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent var1) {
                if (!GUIForm.addsavingsaccount.isVisible()) {
                    GUIForm.addsavingsaccount.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(AddAccount.this.getComponent(0), "Already Opened", "Warning", 0);
                }

                AddAccount.this.dispose();
            }
        });
        var1.setBounds(118, 56, 193, 38);
        this.contentPane.add(var1);
        JButton var2 = new JButton("Add Current Account");
        var2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent var1) {
                if (!GUIForm.addcurrentacc.isVisible()) {
                    GUIForm.addcurrentacc.setVisible(true);
                    AddAccount.this.dispose();
                } else {
                    JOptionPane.showMessageDialog(AddAccount.this.getComponent(0), "Already Opened", "Warning", 0);
                }

            }
        });
        var2.setBounds(118, 124, 193, 38);
        this.contentPane.add(var2);
        JButton var3 = new JButton("Add Student Account");
        var3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent var1) {
                if (!GUIForm.addstudentaccount.isVisible()) {
                    GUIForm.addstudentaccount.setVisible(true);
                    AddAccount.this.dispose();
                } else {
                    JOptionPane.showMessageDialog(AddAccount.this.getComponent(0), "Already Opened", "Warning", 0);
                }

            }
        });
        var3.setBounds(118, 190, 193, 38);
        this.contentPane.add(var3);
        JLabel var4 = new JLabel("Add Account");
        var4.setFont(new Font("Tahoma", 1, 16));
        var4.setHorizontalAlignment(0);
        var4.setBounds(108, 11, 210, 34);
        this.contentPane.add(var4);
    }
}
