public class InvalidAmount extends Exception {
    private static final long serialVersionUID = 1L;

    InvalidAmount(String s) { super(s); }
}
