import GUI.GUIForm;
import java.awt.EventQueue;

public class Application {
    public Application() {
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    GUIForm.login.frame.setVisible(true);
                } catch(Exception var2) {

                }
            }
        });
    }
}
