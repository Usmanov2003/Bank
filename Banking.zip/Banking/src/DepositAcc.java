import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class DepositAcc extends JFrame implements Serializable {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;

    public DepositAcc() {
        this.setTitle("Deposit to Account");
        this.setDefaultCloseOperation(2);
        this.setBounds(100,100,450,300);
        this.contentPane = new JPanel();
        this.contentPane.setBorder(new EmptyBorder(5,5,5,5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout((LayoutManager)null);
        JLabel lblDepositToAccount = new JLabel("Deposit To Account");
        lblDepositToAccount.setFont(new Font("Tahoma",1,16));
        lblDepositToAccount.setHorizontalAlignment(0);
        lblDepositToAccount.setBounds(10,11,414,36);
        this.contentPane.add(lblDepositToAccount);
        JLabel lblName = new JLabel("Account Number: ");
        lblName.setHorizontalAlignment(4);
        lblName.setBounds(0,86,111,14);
        this.contentPane.add(lblName);
        this.textField = new JTextField();
        this.textField.setBounds(121,83,211,20);
        this.contentPane.add(this.textField);
        this.textField.setColumns(10);
        this.textField_1 = new JTextField();
        this.textField_1.setColumns(10);
        this.textField_1.setBounds(121,147,211,20);
        this.contentPane.add(this.textField_1);
        JLabel lblAmount = new JLabel("Amount");
        lblAmount.setHorizontalAlignment(4);
        lblAmount.setBounds(0,150,111,14);
        this.contentPane.add(lblAmount);
        JButton btnDeposit = new JButton("Deposit");
        btnDeposit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                FileIO file =new FileIO();
                Bank bank = file.Read();
                String aacountNum = DepositAcc.this.textField.getText();
                double amt = Double.parseDouble(DepositAcc.this.textField_1.getText());

                try {
                    bank.deposit(aacountNum, amt);
                    JOptionPane.showConfirmDialog(DepositAcc.this.getComponent(0),"Confirm?");
                    JOptionPane.showMessageDialog(DepositAcc.this.getComponent(0),"Deposit Successful");
                } catch (InvalidAmount var8) {
                    JOptionPane.showMessageDialog(DepositAcc.this.getComponent(0),"Sorry! Deposit Amount is Invalid");
                } catch (AccNotFound var9) {
                    JOptionPane.showMessageDialog(DepositAcc.this.getComponent(0),"Sorry! Account is Not Found");
                }

                file.Write(bank);
                GUIForm.UpdateDisplay();
                DepositAcc.this.dispose();
                DepositAcc.this.textField.setText((String)null);
                DepositAcc.this.textField_1.setText((String)null);
            }
        });
        btnDeposit.setBounds(73,212,89,23);
        this.contentPane.add(btnDeposit);
        JButton btnReset = new JButton("Reset");
        btnReset.setBounds(243,212,89,23);
        this.contentPane.add(btnReset);
        btnReset.addActionListener((ActionListener) btnReset);
        btnReset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                DepositAcc.this.textField.setText((String)null);
                DepositAcc.this.textField_1.setText((String)null);
            }
        });
    }
}
