
import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Login {
    JFrame frame;
    private JTextField textField;
    private JPasswordField textField_1;

    public Login() { this.initialize(); }

    private void initialize() {
        this.frame = new JFrame();
        this.frame.setBounds(100,100,450,300);
        this.frame.setDefaultCloseOperation(3);
        this.frame.setTitle("Banking System");
        this.frame.getContentPane().setLayout((LayoutManager)null);
        JLabel label = new JLabel("Banking System");
        label.setFont(new Font("Tahoma",1,17));
        label.setBounds(147,11,151,41);
        this.frame.getContentPane().add(label);
        JLabel lblLoginScreen = new JLabel("Login Screen");
        lblLoginScreen.setFont(new Font("Thoma",0,13));
        lblLoginScreen.setBounds(170,63,101,23);
        this.frame.getContentPane().add(lblLoginScreen);
        JLabel lblUsername = new JLabel("Username: ");
        lblUsername.setFont(new Font("Thoma",0,12));
        lblUsername.setBounds(55,119,64,23);
        this.frame.getContentPane().add(lblUsername);
        JLabel lblPassword = new JLabel("Password: ");
        lblPassword.setFont(new Font("Thoma",0,12));
        lblPassword.setBounds(55,159,64,23);
        this.frame.getContentPane().add(lblPassword);
        this.textField = new JTextField();
        this.textField.setBounds(130,121,86,20);
        this.frame.getContentPane().add(this.textField);
        this.textField.setColumns(10);
        this.textField.setText("admin");
        this.textField_1 = new JPasswordField();
        this.textField_1.setBounds(130,161,86,20);
        this.frame.getContentPane().add(this.textField_1);
        this.textField_1.setColumns(10);
        JButton btnLogin = new JButton("Login");
        btnLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Login.this.textField.setText("admin");
                String user = "admin";
                String pass = Login.this.textField_1.getText();
                if (user.equals("admin") && pass.equals("admin")) {
                    JOptionPane.showMessageDialog(Login.this.frame.getComponent(0),"Login Successfully");
                    Login.this.frame.setVisible(false);
                    GUIForm.menu.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(Login.this.frame.getComponent(0),"Login Failed");
                }
            }
        });
        btnLogin.setBounds(260,138,89,23);
        this.frame.getContentPane().add(btnLogin);
    }
}
