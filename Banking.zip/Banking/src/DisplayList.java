import java.awt.Font;
import java.awt.LayoutManager;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

public class DisplayList extends JFrame {
    private static final long serialVersionUID = 1L;
    static DefaultListModel<String> arr = new DefaultListModel();
    private JPanel contentPane;

    public DisplayList() {
        this.setDefaultCloseOperation(2);
        this.setBounds(100,100,450,300);
        this.contentPane = new JPanel();
        this.contentPane.setBorder(new EmptyBorder(5,5,5,5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout((LayoutManager)null);
        JLabel lblAccountList = new JLabel("Account List");
        lblAccountList.setFont(new Font("Tahoma",1,16));
        lblAccountList.setHorizontalAlignment(0);
        lblAccountList.setBounds(0,11,434,31);
        this.contentPane.add(lblAccountList);
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setVerticalScrollBarPolicy(22);
        scrollPane.setHorizontalScrollBarPolicy(32);
        scrollPane.setBounds(10,66,414,184);
        this.contentPane.add(scrollPane);
        FileIO file = new FileIO();
        Bank bank = file.Read();
        arr = bank.display();
        JList<String> list = new JList(arr);
        scrollPane.setViewportView(list);
    }
}
