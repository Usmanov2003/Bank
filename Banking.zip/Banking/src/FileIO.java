
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class FileIO {

    public FileIO() {
    }

    public Bank Read() {
        Bank bank = null;
        FileInputStream fis = null;
        ObjectInputStream oin = null;

        try {
            fis = new FileInputStream("data.bin");
            oin = new ObjectInputStream(fis);
            bank = (Bank)oin.readObject();
        } catch (Exception var13) {
            bank = new Bank();
        } finally {
            try {
                if (oin != null) {
                    oin.close();
                }

                if (fis != null) {
                    fis.close();
                }
            } catch (IOException var12) {
            }
        }

        return bank;
    }

    public void Write(Bank bank) {
        try {
            FileOutputStream fout = new FileOutputStream("data.bin");
            ObjectOutputStream out = new ObjectOutputStream(fout);
            out.writeObject(bank);
            out.flush();
            fout.close();
        } catch (Exception var4) {

        }
    }
}
