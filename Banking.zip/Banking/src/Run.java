
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;

public class Run {
    private JFrame frmBankingSystem;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try{
                    Run window = new Run();
                    window.frmBankingSystem.setVisible(true);
                } catch (Exception var2) {
                    var2.printStackTrace();
                }
            }
        });
    }

    public Run() { this.initialize();}

    private void initialize() {
        this.frmBankingSystem = new JFrame();
        this.frmBankingSystem.setBackground(Color.LIGHT_GRAY);
        this.frmBankingSystem.setTitle("Banking System");
        this.frmBankingSystem.setBounds(100,100,450,300);
        this.frmBankingSystem.setDefaultCloseOperation(3);
        JButton btnNewButton = new JButton("New button");
        btnNewButton.setVerticalAlignment(3);
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

            }
        });
        this.frmBankingSystem.getContentPane().add(btnNewButton, "North");
    }
}