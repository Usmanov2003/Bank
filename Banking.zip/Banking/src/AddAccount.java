
import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class AddAccount extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    public AddAccount() {
        this.setTitle("Add Account");
        this.setDefaultCloseOperation(2);
        this.setBounds(100, 100, 450, 300);
        this.contentPane = new JPanel();
        this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout((LayoutManager)null);
        JButton btnAddCurrentAccount = new JButton("Add Saving Account");
        btnAddCurrentAccount.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GUIForm.addsavingsaccount.setVisible(true);
                AddAccount.this.dispose();
            }
        });
        btnAddCurrentAccount.setBounds(118, 56, 193, 38);
        this.contentPane.add(btnAddCurrentAccount);
        JButton button = new JButton("Add Current Account");
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GUIForm.addcurrentacc.setVisible(true);
                AddAccount.this.dispose();
            }
        });
        button.setBounds(118, 124, 193, 38);
        this.contentPane.add(button);
        JButton btnAddStudentAccount = new JButton("Add Student Account");
        btnAddStudentAccount.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GUIForm.addstudentaccount.setVisible(true);
                AddAccount.this.dispose();
            }
        });
        btnAddStudentAccount.setBounds(118, 190, 193, 38);
        this.contentPane.add(btnAddStudentAccount);
        JLabel lblAddAccount = new JLabel("Add Account");
        lblAddAccount.setFont(new Font("Tahoma", 1, 16));
        lblAddAccount.setHorizontalAlignment(0);
        lblAddAccount.setBounds(108, 11, 210, 34);
        this.contentPane.add(lblAddAccount);
    }
}
