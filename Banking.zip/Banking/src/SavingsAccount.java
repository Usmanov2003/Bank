public class SavingsAccount extends BankAccount {
    private static final long serialVersionUID = 1L;
    float rate = 0.05F;
    double maxWithLimit;

    public SavingsAccount(String name,  double balance, double maxWithLimit) {
        super(name, balance, 2000.0);
        this.maxWithLimit = maxWithLimit;
    }

    public double getNetBalance() {
        double NetBalance = this.getBalance() + this.getBalance() * (double)this.rate;
        return NetBalance;
    }

    public void withdraw(double amount) throws MaxWithdraw, MaxBalance {
        if (amount < this.maxWithLimit) {
            super.withdraw(amount);
        } else {
            throw new MaxWithdraw("Maximum Withdraw Limit Exceed");
        }
    }
}
