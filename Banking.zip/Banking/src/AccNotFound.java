public class AccNotFound extends Exception {
    private static final long serialVersionUID = 1L;

    AccNotFound(String s) { super(s); }
}
